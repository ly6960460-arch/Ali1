# Shadow Demon — Android project

Arabic-first Android video library with a dark crimson/black identity. Current source version: **0.3.1**.

## Features in this source
- Arabic RTL interface and custom Shadow Demon launcher icon.
- Import multiple local videos using Android's system document picker.
- Persist library entries, favorites, and last-watched timestamps locally.
- Search and browse Home, Explore, Favorites, and My Library.
- Play selected videos with AndroidX Media3 ExoPlayer.
- Load an external Arabic subtitle file (`.srt` or `.vtt`).
- Switch between portrait and landscape playback.
- Remove an entry from the in-app catalog without deleting the original video.
- GitHub Actions workflow for cloud APK builds on pushes, pull requests, tags, or manual runs; version tags publish a downloadable GitHub Release asset.

## Get an APK with GitHub Actions
1. Create a GitHub repository and upload the **contents** of this folder to its `main` branch.
2. Open the repository's **Actions** tab and enable Actions if GitHub prompts you.
3. Select **Build Shadow Demon APK** and press **Run workflow**. A push or pull request to `main`/`master` also starts a build.
4. Open the completed workflow run and download **ShadowDemon-debug-apk** from Artifacts. Artifacts are retained for 14 days.
5. Optional: create and push a version tag such as `v0.3.1`; the workflow will also publish the APK as a GitHub Release asset.
6. On Android, open the downloaded APK and approve installation from that source if Android asks.

The build runs on GitHub's hosted runner; you do not need Android Studio on your phone. This requires a GitHub account and an initial upload of the project. ChatGPT cannot publish to your GitHub account unless you explicitly connect an authorized GitHub integration.

## Build locally
- Install Android Studio stable and JDK 17.
- Open this folder in Android Studio and install Android SDK Platform 35.
- Build via **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
- The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk` after a successful build.

## Current limitations
- This archive contains source code, not a compiled APK. This execution environment has no Android SDK or Gradle installed and cannot reach the Gradle download host, so compilation/device testing could not be performed here.
- The app plays local videos; it does not include a streaming backend, online anime catalog, account system, cloud sync, or DRM.
- Add only media you own or are licensed to use. Playback compatibility depends on the media file and device decoders.
- The local catalog stores document URIs. If the source file is deleted or access is revoked, the entry may no longer play.
