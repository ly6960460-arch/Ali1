package com.shadowdemon.app

import android.content.Context
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Ink = Color(0xFF090A0F)
private val Panel = Color(0xFF19151F)
private val Panel2 = Color(0xFF24232C)
private val Crimson = Color(0xFFE32645)
private val Muted = Color(0xFFB8B8C5)
private val White = Color(0xFFF7F5FA)
private const val PREFS = "shadow_demon_library"
private const val CATALOG_KEY = "catalog_json"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShadowDemonApp(onOrientation = { landscape ->
                requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            })
        }
    }
}

private data class ClipItem(
    val id: String,
    val uri: String,
    val title: String,
    val category: String = "محلي",
    val favorite: Boolean = false,
    val lastWatched: Long = 0L
)

private fun loadCatalog(context: Context): List<ClipItem> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(CATALOG_KEY, "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(ClipItem(
                    id = o.optString("id", UUID.randomUUID().toString()),
                    uri = o.optString("uri", ""),
                    title = o.optString("title", "فيديو بدون اسم"),
                    category = o.optString("category", "محلي"),
                    favorite = o.optBoolean("favorite", false),
                    lastWatched = o.optLong("lastWatched", 0L)
                ))
            }
        }.filter { it.uri.isNotBlank() }
    } catch (_: Exception) { emptyList() }
}

private fun saveCatalog(context: Context, clips: List<ClipItem>) {
    val array = JSONArray()
    clips.forEach { clip ->
        array.put(JSONObject().apply {
            put("id", clip.id)
            put("uri", clip.uri)
            put("title", clip.title)
            put("category", clip.category)
            put("favorite", clip.favorite)
            put("lastWatched", clip.lastWatched)
        })
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(CATALOG_KEY, array.toString()).apply()
}

private fun displayName(context: Context, uri: Uri): String {
    return try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0)?.substringBeforeLast('.', cursor.getString(0) ?: "") else null
        }?.takeIf { it.isNotBlank() } ?: "فيديو جديد"
    } catch (_: Exception) { "فيديو جديد" }
}

@Composable
fun ShadowDemonApp(onOrientation: (Boolean) -> Unit) {
    val context = LocalContext.current
    val catalog = remember { mutableStateListOf<ClipItem>().apply { addAll(loadCatalog(context)) } }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    var playerOpen by remember { mutableStateOf(false) }
    var landscape by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("الكل") }
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    var status by remember { mutableStateOf("أضف فيديوهاتك الخاصة لتبدأ مكتبتك") }

    fun persist() {
        saveCatalog(context, catalog.toList())
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            var added = 0
            uris.forEach { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (catalog.none { it.uri == uri.toString() }) {
                    catalog.add(ClipItem(UUID.randomUUID().toString(), uri.toString(), displayName(context, uri)))
                    added++
                }
            }
            persist()
            status = if (added > 0) "تمت إضافة $added فيديو إلى مكتبتك" else "الفيديوهات المحددة موجودة مسبقاً في المكتبة"
        }
    }
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            subtitleUri = uri
            status = "تم اختيار الترجمة العربية؛ سيعاد تحميل المشغّل لتطبيقها"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Crimson, onPrimary = White, onBackground = White, onSurface = White, secondary = Muted)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            if (playerOpen && videoUri != null) {
                PlayerScreen(
                    videoUri = videoUri!!,
                    subtitleUri = subtitleUri,
                    landscape = landscape,
                    onToggleOrientation = { landscape = !landscape; onOrientation(landscape) },
                    onPickSubtitle = { subtitlePicker.launch(arrayOf("text/*", "application/x-subrip", "application/octet-stream")) },
                    onBack = { playerOpen = false; landscape = false; onOrientation(false) }
                )
            } else {
                Scaffold(containerColor = Ink, bottomBar = {
                    NavigationBar(containerColor = Color(0xFF101016), contentColor = Muted) {
                        listOf(
                            Triple("الرئيسية", Icons.Default.Home, "home"),
                            Triple("استكشاف", Icons.Default.Explore, "explore"),
                            Triple("المفضلة", Icons.Default.FavoriteBorder, "favorites"),
                            Triple("مكتبتي", Icons.Default.LibraryBooks, "library")
                        ).forEach { (label, icon, _) ->
                            NavigationBarItem(selected = selectedTab == label, onClick = { selectedTab = label }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Crimson, selectedTextColor = Crimson, indicatorColor = Color(0xFF32111A), unselectedIconColor = Muted, unselectedTextColor = Muted))
                        }
                    }
                }) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).background(Ink)) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
                            Spacer(Modifier.height(18.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF4B1020), Color(0xFF190A12)))), contentAlignment = Alignment.Center) { Text("☠", fontSize = 25.sp, color = Crimson) }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("SHADOW DEMON", fontSize = 18.sp, fontWeight = FontWeight.Black, color = White, letterSpacing = 1.2.sp)
                                    Text("ANIME • SHORT SERIES • AR", fontSize = 9.sp, color = Muted, letterSpacing = 1.sp)
                                }
                                IconButton(onClick = { searchOpen = !searchOpen }) { Icon(Icons.Default.Search, contentDescription = "بحث", tint = White) }
                            }
                            if (searchOpen) {
                                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("ابحث في مكتبتك…", color = Muted) }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Crimson, unfocusedBorderColor = Panel2, focusedTextColor = White, unfocusedTextColor = White))
                            }
                            Spacer(Modifier.height(22.dp))
                            Box(Modifier.fillMaxWidth().height(218.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF521326), Color(0xFF21131F), Color(0xFF101018)))).padding(18.dp)) {
                                Column(Modifier.align(Alignment.BottomStart)) {
                                    Surface(color = Crimson.copy(alpha = 0.18f), shape = RoundedCornerShape(50)) { Text("مكتبتك الخاصة", color = Color(0xFFFF8195), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) }
                                    Spacer(Modifier.height(9.dp))
                                    Text("ليلة الظلال", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = White)
                                    Text("لقطاتك المفضلة • ترجمة عربية", fontSize = 12.sp, color = Muted)
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick = { videoPicker.launch(arrayOf("video/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Crimson), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("أضف فيديوهات", fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text("影", modifier = Modifier.align(Alignment.TopEnd), fontSize = 86.sp, color = Color.White.copy(alpha = 0.06f), fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.height(12.dp))
                            Text(status, color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(22.dp))
                            val heading = when (selectedTab) {
                                "المفضلة" -> "مقاطعك المفضلة"
                                "مكتبتي" -> "مكتبة الفيديوهات"
                                "استكشاف" -> "استكشف حسب التصنيف"
                                else -> "اكتشف عالم الظلال"
                            }
                            Text(heading, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = White)
                            Spacer(Modifier.height(12.dp))
                            if (selectedTab == "الرئيسية" || selectedTab == "استكشاف") {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("الكل", "محلي").forEach { category ->
                                        FilterChip(selected = selectedCategory == category, onClick = { selectedCategory = category }, label = { Text(category) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Crimson, selectedLabelColor = White, containerColor = Panel2, labelColor = Muted), border = null)
                                    }
                                }
                                Spacer(Modifier.height(16.dp))
                            }
                            val visibleClips = catalog.filter { clip ->
                                val matchesCategory = selectedCategory == "الكل" || clip.category == selectedCategory
                                val matchesQuery = query.isBlank() || clip.title.contains(query.trim(), ignoreCase = true)
                                val matchesTab = when (selectedTab) {
                                    "المفضلة" -> clip.favorite
                                    "مكتبتي" -> true
                                    else -> true
                                }
                                matchesCategory && matchesQuery && matchesTab
                            }.let { items -> if (selectedTab == "الرئيسية") items.sortedByDescending { it.lastWatched } else items }
                            Text("${visibleClips.size} فيديو", color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(10.dp))
                            if (visibleClips.isEmpty()) {
                                EmptyLibrary(
                                    message = if (selectedTab == "المفضلة") "ما عندك مقاطع مفضلة بعد" else if (query.isNotBlank()) "ما لقينا نتائج مطابقة" else "مكتبتك فارغة حالياً. أضف فيديوهات تملكها أو لديك إذن باستخدامها.",
                                    onAdd = { videoPicker.launch(arrayOf("video/*")) }
                                )
                            } else {
                                visibleClips.forEach { clip ->
                                    key(clip.id) {
                                        ClipCard(
                                            clip = clip,
                                            onClick = {
                                                videoUri = Uri.parse(clip.uri)
                                                playerOpen = true
                                                subtitleUri = null
                                                val index = catalog.indexOfFirst { it.id == clip.id }
                                                if (index >= 0) { catalog[index] = catalog[index].copy(lastWatched = System.currentTimeMillis()); persist() }
                                            },
                                            onFavorite = {
                                                val index = catalog.indexOfFirst { it.id == clip.id }
                                                if (index >= 0) { catalog[index] = catalog[index].copy(favorite = !catalog[index].favorite); persist() }
                                            },
                                            onDelete = {
                                                catalog.removeAll { it.id == clip.id }
                                                persist()
                                                status = "تم حذف المقطع من المكتبة (لم يُحذف الملف الأصلي من الجهاز)"
                                            }
                                        )
                                        Spacer(Modifier.height(10.dp))
                                    }
                                }
                            }
                            OutlinedButton(onClick = { videoPicker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = White)) { Icon(Icons.Default.VideoLibrary, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("إضافة فيديو من الجهاز") }
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyLibrary(message: String, onAdd: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Crimson, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(10.dp))
        Text(message, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Crimson)) { Text("اختيار فيديو") }
    }
}

@Composable
private fun ClipCard(clip: ClipItem, onClick: () -> Unit, onFavorite: () -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onClick).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 74.dp, height = 90.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF4A1424), Color(0xFF20202B), Color(0xFF101016)))), contentAlignment = Alignment.Center) { Text("▶", fontSize = 30.sp, color = Crimson.copy(alpha = 0.9f)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(clip.title, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp)); Text(if (clip.lastWatched > 0L) "محلي • تمت المشاهدة" else "فيديو محلي", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp)); Text("اضغط للتشغيل", color = Color(0xFFFF8195), fontSize = 11.sp)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = onFavorite) { Icon(if (clip.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "المفضلة", tint = if (clip.favorite) Crimson else Muted) }
            IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, contentDescription = "حذف من المكتبة", tint = Muted) }
        }
    }
}

private fun subtitleMimeType(context: Context, uri: Uri): String {
    val name = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (_: Exception) { null }
    return if (name?.endsWith(".vtt", ignoreCase = true) == true) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
}

@Composable
private fun PlayerScreen(videoUri: Uri, subtitleUri: Uri?, landscape: Boolean, onToggleOrientation: () -> Unit, onPickSubtitle: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember(videoUri, subtitleUri) {
        ExoPlayer.Builder(context).build().apply {
            val builder = MediaItem.Builder().setUri(videoUri)
            if (subtitleUri != null) {
                val subtitle = MediaItem.SubtitleConfiguration.Builder(subtitleUri)
                    .setMimeType(subtitleMimeType(context, subtitleUri))
                    .setLanguage("ar")
                    .setLabel("العربية")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
                builder.setSubtitleConfigurations(listOf(subtitle))
            }
            setMediaItem(builder.build())
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع", color = White) }
            Spacer(Modifier.weight(1f))
            Text("SHADOW DEMON", color = Crimson, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onPickSubtitle) { Icon(Icons.Default.Subtitles, contentDescription = "اختيار الترجمة", tint = White) }
            TextButton(onClick = onToggleOrientation) { Text(if (landscape) "عمودي" else "أفقي", color = White) }
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { ctx -> PlayerView(ctx).apply { this.player = player; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; useController = true } },
            update = { it.player = player }
        )
        Text("الترجمة: ${if (subtitleUri == null) "لم يتم اختيار ملف ترجمة" else "العربية"}", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().background(Ink).padding(12.dp))
    }
}
